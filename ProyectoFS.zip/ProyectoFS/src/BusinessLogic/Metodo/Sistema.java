package BusinessLogic.Metodo;

public class Sistema {
    public void iniciarSecion(){

    }

    public void registrarCliente(){

    }

    public void actualizarDatos(){

    }

    public void registrarEmpleados(){

    }

}
