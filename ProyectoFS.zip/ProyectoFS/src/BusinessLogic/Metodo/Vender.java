package BusinessLogic.Metodo;

public class Vender {

    public void agregarProductos(){

    }
    
    public void calcularCreditos(){

    }

    public void calcularTotal(){

    }

    public void calcularSubtotal(){

    }

    public void calcularIva(){
        
    }
}
