package BusinessLogic.Metodo;

public class FacturaDatos {
    
    public void obtenerDatosCliente(){
    
    }
    
    public void obtenerDatosEmpleado(){
            
    }
    
     public void obtenerDatosVenta(){
            
    }
    
    
}
