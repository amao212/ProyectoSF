package BusinessLogic.Metodo;

public class FacturaElectronica {
    
    public void enviarFactura(){
        
    }
}
